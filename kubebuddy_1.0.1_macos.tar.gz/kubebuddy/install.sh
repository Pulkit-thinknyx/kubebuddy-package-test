#!/bin/bash

set -e  # Exit immediately if a command exits with a non-zero status

echo "Installing KubeBuddy: AI Powered Kubernetes Dashboard"

# Function to print error and exit
function error_exit {
  echo "Error: $1"
  exit 1
}

# Check Python version (>= 3.10)
if ! command -v python3 &> /dev/null; then
  error_exit "Python3 is not installed. Please install Python 3.10 or newer."
fi

PYTHON_VERSION=$(python3 -c 'import sys; print(".".join(map(str, sys.version_info[:2])))')
REQUIRED_VERSION="3.10"

if [[ "$(printf '%s\n' "$REQUIRED_VERSION" "$PYTHON_VERSION" | sort -V | head -n1)" != "$REQUIRED_VERSION" ]]; then
  error_exit "Python version must be >= 3.10. Found version: $PYTHON_VERSION"
fi

# Check pip
if ! command -v pip &> /dev/null; then
  error_exit "pip is not installed. Please install pip before proceeding."
fi

# Check venv module
if ! python3 -m venv --help &> /dev/null; then
  error_exit "venv module is not available. Please ensure Python was installed with venv support."
fi

echo "All dependencies are satisfied!"
echo "--------------------------------"

echo "Creating Virtual Environment..."
python3 -m venv buddyenv

source ./buddyenv/bin/activate

echo "Installing dependencies..."
pip install -r requirements.txt

echo "Installation complete!"

echo "Setting up project..."
python3 manage.py makemigrations main

echo "Creating Database..."
python3 manage.py migrate

echo "-----------------------------------------------------------------------------------------------"
echo "KubeBuddy is ready to go! Run the following command to start the server:"
echo "bash run.sh --port <port_number> --host <host_address>"
echo "Both --host and --port are optional. Defaults are host=127.0.0.1 and port=8000."
echo "Example: bash run.sh --port 8080 --host 0.0.0.0"
