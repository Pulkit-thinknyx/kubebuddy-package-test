#!/bin/bash

# Default port
PORT=8000

# If a port is passed as the first argument, use it
if [ ! -z "$1" ]; then
  PORT="$1"
fi

source ./buddyenv/bin/activate

python3 manage.py runserver $PORT